<script src="<?php echo e(asset('bootstrap/js/mdb.umd.min.js')); ?>"></script>
<?php /**PATH C:\Users\pc\Documents\MobileApp\resources\views/partials/footer.blade.php ENDPATH**/ ?>