<script src="<?php echo e(asset('bootstrap/js/mdb.umd.min.js')); ?>"></script>
 <!-- Font Awesome CDN -->
 <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<?php /**PATH C:\Users\pc\Documents\_mobile\resources\views/partials/footer.blade.php ENDPATH**/ ?>