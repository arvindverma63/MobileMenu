<!DOCTYPE html>
<html lang="en">
 <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
 <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </style>
    <div class="container" style="margin-top: 16%; margin-bottom: 10%;">
        <!-- Delivery Section -->
        <div class="card-container d-flex justify-content-between align-items-center mb-3">
            <div>
                <small class="text-muted">DELIVERY TO</small>
                <h6 class="mb-0">Kanpur <i class="fas fa-chevron-down"></i></h6>
            </div>
            <button class="btn btn-link p-0 text-primary">
                <i class="fas fa-gift"></i> Offers
            </button>
        </div>

        <!-- Offer Banner -->
        <div id="offerCarousel" class="carousel slide mb-3" data-mdb-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="card bg-danger text-white border rounded">
                        <img src="foodImages/1.jpeg" class="card-img" alt="Offer">
                        <div class="card-img-overlay d-flex flex-column justify-content-center align-items-center text-center">
                            <h3 class="fw-bold">50% OFF</h3>
                            <p class="mb-0">First Order</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Categories Section -->
        <h5 class="mb-3">Categories</h5>
        <div class="card-container d-flex overflow-auto category-scroll">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="me-3 text-center" style="flex: 0 0 auto;">
                    <div class="rounded-circle bg-light d-flex align-items-center justify-content-center shadow-sm border" style="width: 80px; height: 80px; overflow: hidden;">
                        <img src="<?php echo e($menu['itemImage']); ?>" alt="" class="img-fluid">
                    </div>
                    <p class="mt-2 small text-muted mb-0"><?php echo e($menu['category']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Restaurant Section -->
        <div class="restaurant-section d-flex justify-content-between align-items-center mt-4 mb-3" id="items">
            <h5>All Restaurants Nearby</h5>
            <button class="btn btn-outline-white btn-sm text-white">Sort/Filter</button>
        </div>
        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 mb-3">
                    <div class="restaurant-card h-100 shadow-sm border rounded">
                        <div class="row g-0">
                            <div class="col-4">
                                <img src="<?php echo e(asset($restaurant['itemImage'])); ?>" class="img-fluid rounded-start h-100" alt="<?php echo e($restaurant['itemName']); ?>" style="object-fit: cover;">
                            </div>
                            <div class="col-8">
                                <div class="card-body p-2">
                                    <h5 class="card-title mb-1"><?php echo e($restaurant['itemName']); ?></h5>
                                    <p class="card-text mb-1 text-muted"><?php echo e($restaurant['category']); ?></p>
                                    <p class="card-text mb-1 text-muted"><?php echo e($restaurant['price']); ?></p>
                                    <p class="card-text mb-2 text-danger">Ingredients</p>
                                    <div class="d-flex flex-wrap">
                                        <?php $__currentLoopData = $restaurant['ingredients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-success me-1 mb-1"><?php echo e($ingredient['ingredientName']); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <button class="btn btn-primary btn-sm">Order Now</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Bottom Navigation Bar -->
    <div class="position-fixed bottom-0 w-100 bg-light border-top shadow-sm">
        <div class="d-flex justify-content-around py-2">
            <a href="#" class="text-center text-decoration-none text-dark">
                <i class="fas fa-home fa-lg"></i> <!-- Home Icon -->
                <p class="mb-0 small">Home</p>
            </a>
            <a href="#" class="text-center text-decoration-none text-dark">
                <i class="fas fa-search fa-lg"></i> <!-- Search Icon -->
                <p class="mb-0 small">Search</p>
            </a>
            <a href="#" class="text-center text-decoration-none text-dark">
                <i class="fas fa-shopping-cart fa-lg"></i> <!-- Cart Icon -->
                <p class="mb-0 small">Cart</p>
            </a>
            <a href="#" class="text-center text-decoration-none text-dark">
                <i class="fas fa-user fa-lg"></i> <!-- Profile Icon -->
                <p class="mb-0 small">Profile</p>
            </a>
        </div>
    </div>

    <style>
        /* Bottom navigation styles */
        .position-fixed.bottom-0 {
            z-index: 1030;
        }

        .position-fixed.bottom-0 a {
            color: #555;
        }

        .position-fixed.bottom-0 a:hover {
            color: #000;
        }
    </style>

    <!-- Font Awesome CDN -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>


    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\pc\Documents\MobileApp\resources\views/index.blade.php ENDPATH**/ ?>