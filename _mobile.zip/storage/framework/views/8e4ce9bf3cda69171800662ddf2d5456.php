<head>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/mdb.min.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>DQ</title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<?php /**PATH C:\Users\pc\Documents\MobileApp\resources\views/partials/head.blade.php ENDPATH**/ ?>